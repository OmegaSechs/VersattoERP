<?php

    $dbHost = 'localhost:D:/Eng. de Software/Banco de dados/NOVOBANCO.FDB';
    $dbUsername = 'SYSDBA'; 
    $dbPassword = 'masterkey'; 

    $conexao = ibase_connect($dbHost, $dbUsername, $dbPassword);

    if (!$conexao) {
        echo "Erro na conexão com o banco de dados Firebird.";
    } else {
        echo "Conexão com o Firebird efetuada com sucesso.";
    }

?>
