<?php
// Conectar ao banco de dados Firebird
$host = 'localhost';
$porta = '3060';
$banco = 'C:\xampp\htdocs\Versatto\Desenvolvimento\Versatto.FDB';
$usuario = 'SYSDBA';
$senha = '123456';

// Estabelecendo a conexão
$conexao = ibase_connect("$host/$porta:$banco", $usuario, $senha);

if (!$conexao) {
    die('Erro ao conectar ao banco de dados: ' . ibase_errmsg());
}

// Captura os dados do formulário via POST
$id_produto = $_POST['id_produto']; // Captura o ID 
//var_dump($id_produto); die(); verificar o que a variável está recebendo e matar o código(depois do die)
$nome = $_POST['nome'];
$preco_custo = $_POST['preco_custo'];
$preco_venda = $_POST['preco_venda'];
$estoque_minimo = $_POST['estoque_minimo'];
$estoque_maximo = $_POST['estoque_maximo'];
$quantidade_estoque = $_POST['quantidade_estoque'];
$descricao_produto = $_POST['descricao_produto'];

// Consulta SQL para inserir o produto
$query = "INSERT INTO produtos (nome_produto, preco_custo, preco_venda, estoque_minimo, estoque_maximo, quantidade_estoque, descricao_produto) 
          VALUES ('$nome', '$preco_custo', '$preco_venda', '$estoque_minimo', '$estoque_maximo', '$quantidade_estoque', '$descricao_produto')";

// Executa a consulta SQL
$resultado = ibase_query($conexao, $query);

if ($resultado) {
    echo "Produto cadastrado com sucesso!";
    header('location:listaProdutos.php');
} else {
    echo "Erro ao cadastrar o produto: " . ibase_errmsg();
}

// Fecha a conexão
ibase_close($conexao);
?>
