<?php
$host = 'localhost';
$porta = '3060';
$banco = 'C:\xampp\htdocs\Versatto\Desenvolvimento\Versatto.FDB';
$usuario = 'SYSDBA';
$senha = '123456';

// Estabelecendo a conexão
$conexao = ibase_connect("$host/$porta:$banco", $usuario, $senha);

if (!$conexao) {
    die('Erro ao conectar ao banco de dados: ' . ibase_errmsg());
}

// Consulta para pegar o último ID cadastrado
$query = "SELECT MAX(id_produto) AS max_id FROM produtos";
$result = ibase_query($conexao, $query);


if ($row = ibase_fetch_assoc($result)) {
    // Verifica se a chave 'max_id' existe e não é NULL
    if (array_key_exists('max_id', $row) && $row['max_id'] !== null) {
        $id_produto = $row['max_id'] + 1; // Incrementa o último ID em 1, se existir
    }
}

// Fecha a conexão
ibase_close($conexao);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Produtos</title>
  <!--    <link rel="stylesheet" href="CadProdutos.css"> -->
      <link rel="stylesheet" href="Entradas.css">
</head>
<body>
    <div class="box">
        <div class="container">
            <h2>Cadastro de Produtos</h2>
            
            <form action="inserirProduto.php" method="POST">
                
                <div class="input-group">
                <label>ID</label>
                <input type="number" readonly value="<?php echo $id_produto; ?>">
                </div>

                <div class="input-group">
                    <input type="text" id="nome" name="nome" placeholder=" " required>
                    <label for="nome">Nome do Produto</label>                    
                </div>

                <div class="input-group">
                    <input type="number" id="preco_custo" name="preco_custo" step="0.01" placeholder=" " required>
                    <label for="preco_custo">Custo</label>
                </div>

                <div class="input-group">
                    <input type="number" id="preco_venda" name="preco_venda" step="0.01" placeholder=" " required>
                    <label for="preco_venda">Valor de Venda</label>
                </div>

                <div class="input-group">
                    <input type="number" id="estoque_minimo" name="estoque_minimo" placeholder=" " required>
                    <label for="estoque_minimo">Estoque Mínimo</label>
                </div>

                <div class="input-group">
                    <input type="number" id="estoque_maximo" name="estoque_maximo" placeholder=" " required>
                    <label for="estoque_maximo">Estoque Máximo</label>
                </div>

                <div class="input-group">
                    <input type="number" id="quantidade_estoque" name="quantidade_estoque" placeholder=" " required>
                    <label for="quantidade_estoque">Estoque Disponível</label>
                </div>

                <div class="input-group">
                    <input type="text" id="descricao_produto" name="descricao_produto" placeholder=" " required>
                    <label for="descricao_produto">Descrição</label>
                </div> 
                
                <div class="input-group">
                <a href="listaProdutos.php"><button class="return" type="button">Retornar</button></a>
                    <button class="submit" type="submit">Cadastrar Produto</button>
                </div>              
            </form>
        </div>
    </div>
</body>
</html>
