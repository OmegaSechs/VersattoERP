<?php
// Conectar ao banco de dados Firebird
$host = 'localhost';
$porta = '3060';
$banco = 'C:\xampp\htdocs\Versatto\Desenvolvimento\Versatto.FDB';
$usuario = 'SYSDBA';
$senha = '123456';

// Estabelecendo a conexão
$conexao = ibase_connect("$host/$porta:$banco", $usuario, $senha);

if (!$conexao) {
    die('Erro ao conectar ao banco de dados: ' . ibase_errmsg());
}

// Verificar se os dados foram enviados
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_produto = (int)$_POST['id_produto'];
    $nome = trim($_POST['nome']);
    $preco_custo = (float)$_POST['preco_custo'];
    $preco_venda = (float)$_POST['preco_venda'];
    $estoque_minimo = (int)$_POST['estoque_minimo'];
    $estoque_maximo = (int)$_POST['estoque_maximo'];
    $quantidade_estoque = (int)$_POST['quantidade_estoque'];
    $descricao_produto = trim($_POST['descricao_produto']);

    // Atualizar o produto no banco de dados
    $query = "UPDATE produtos SET 
              NOME_PRODUTO = ?, 
              PRECO_CUSTO = ?, 
              PRECO_VENDA = ?, 
              ESTOQUE_MINIMO = ?, 
              ESTOQUE_MAXIMO = ?, 
              QUANTIDADE_ESTOQUE = ?, 
              DESCRICAO_PRODUTO = ?
              WHERE ID_PRODUTO = ?";

    $stmt = ibase_prepare($conexao, $query);
    $resultado = ibase_execute($stmt, $nome, $preco_custo, $preco_venda, $estoque_minimo, $estoque_maximo, $quantidade_estoque, $descricao_produto, $id_produto);

    if ($resultado) {
        echo 'Produto atualizado com sucesso!';
    } else {
        echo 'Erro ao atualizar o produto: ' . ibase_errmsg();
    }
}

// Fechar a conexão
ibase_close($conexao);
?>
