<?php
// Conectar ao banco de dados Firebird
$host = 'localhost';
$porta = '3060';
$banco = 'C:\xampp\htdocs\Versatto\Desenvolvimento\Versatto.FDB';
$usuario = 'SYSDBA';
$senha = '123456';

// Estabelecendo a conexão
$conexao = ibase_connect("$host/$porta:$banco", $usuario, $senha);

if (!$conexao) {
    die('Erro ao conectar ao banco de dados: ' . ibase_errmsg());
}

// Verificar se o ID foi passado na URL
if (isset($_GET['id'])) {
    $id_produto = (int)$_GET['id'];

    // Buscar os dados do produto
    $query = "SELECT * FROM produtos WHERE ID_PRODUTO = ?";
    $stmt = ibase_prepare($conexao, $query);
    $resultado = ibase_execute($stmt, $id_produto);

    if ($produto = ibase_fetch_assoc($resultado)) {
        // Exibir o formulário de edição com os valores preenchidos
    } else {
        echo "Produto não encontrado.";
        exit;
    }
} else {
    echo "ID de produto não informado.";
    exit;
}

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Receber os dados do formulário
    $id_produto = $_POST['id_produto'];
    $nome = $_POST['nome'];
    $preco_custo = $_POST['preco_custo'];
    $preco_venda = $_POST['preco_venda'];
    $estoque_minimo = $_POST['estoque_minimo'];
    $estoque_maximo = $_POST['estoque_maximo'];
    $quantidade_estoque = $_POST['quantidade_estoque'];
    $descricao_produto = $_POST['descricao_produto'];

    // Atualizar os dados no banco de dados
    $update_query = "
        UPDATE produtos
        SET
            NOME_PRODUTO = ?,
            PRECO_CUSTO = ?,
            PRECO_VENDA = ?,
            ESTOQUE_MINIMO = ?,
            ESTOQUE_MAXIMO = ?,
            QUANTIDADE_ESTOQUE = ?,
            DESCRICAO_PRODUTO = ?
        WHERE ID_PRODUTO = ?
    ";

    $stmt_update = ibase_prepare($conexao, $update_query);
    $result_update = ibase_execute($stmt_update, $nome, $preco_custo, $preco_venda, $estoque_minimo, $estoque_maximo, $quantidade_estoque, $descricao_produto, $id_produto);

    if ($result_update) {
        // Redirecionar para a página listaProdutos.php após a atualização
        header("Location: listaProdutos.php");
        exit(); // Evitar que o código continue executando após o redirecionamento
    } else {
        echo "Erro ao atualizar o produto.";
    }
}

// Fechar a conexão depois de usar
ibase_close($conexao);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produto</title>
    <link href="editarProduto.css" rel="Stylesheet">
</head>
<body>
    <h2>Editar Produto</h2>

    <form action="" method="POST">
        <input type="hidden" name="id_produto" value="<?php echo $produto['ID_PRODUTO']; ?>">

        <label for="nome">Nome do Produto:</label>
        <input type="text" id="nome" name="nome" value="<?php echo $produto['NOME_PRODUTO']; ?>" required>

        <label for="preco_custo">Preço de Custo:</label>
        <input type="number" id="preco_custo" name="preco_custo" step="0.01" value="<?php echo $produto['PRECO_CUSTO']; ?>" required>

        <label for="preco_venda">Preço de Venda:</label>
        <input type="number" id="preco_venda" name="preco_venda" step="0.01" value="<?php echo $produto['PRECO_VENDA']; ?>" required>

        <label for="estoque_minimo">Estoque Mínimo:</label>
        <input type="number" id="estoque_minimo" name="estoque_minimo" value="<?php echo $produto['ESTOQUE_MINIMO']; ?>" required>

        <label for="estoque_maximo">Estoque Máximo:</label>
        <input type="number" id="estoque_maximo" name="estoque_maximo" value="<?php echo $produto['ESTOQUE_MAXIMO']; ?>" required>

        <label for="quantidade_estoque">Quantidade em Estoque:</label>
        <input type="number" id="quantidade_estoque" name="quantidade_estoque" value="<?php echo $produto['QUANTIDADE_ESTOQUE']; ?>" required>

        <label for="descricao_produto">Descrição:</label>
        <input type="text" id="descricao_produto" name="descricao_produto" value="<?php echo $produto['DESCRICAO_PRODUTO']; ?>" required>

        <button type="submit" class="add">Atualizar Produto</button>
    </form>
</body>
</html>
