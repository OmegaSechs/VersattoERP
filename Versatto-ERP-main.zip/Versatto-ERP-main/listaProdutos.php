<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos</title>
    
    <link href="Home.css" rel="stylesheet">
    <link href="Listas.css" rel="stylesheet">

</head>
<body>

<?php
// Conexão com o banco de dados Firebird
$host = 'localhost';
$porta = '3060'; // Porta confgurada no firebird.conf
$banco = 'C:\xampp\htdocs\Versatto\Desenvolvimento\Versatto.FDB'; // Caminho do seu banco de dados
$usuario = 'SYSDBA';
$senha = '123456'; // Sua senha

$conexao = ibase_connect("$host/$porta:$banco", $usuario, $senha);

// Verifica se a conexão foi bem-sucedida
if (!$conexao) {
    die('Erro ao conectar ao banco de dados: ' . ibase_errmsg());
}

// Consulta SQL para buscar os produtos cadastrados
$query = "SELECT id_produto, nome_produto, estoque_minimo, estoque_maximo, quantidade_estoque, preco_custo, preco_venda FROM produtos";
$resultado = ibase_query($conexao, $query);

if (!$resultado) {
    die('Erro na consulta: ' . ibase_errmsg());
}
?>
<main class="page">
<div id="sidebar-container" class="sidebar">
            <button class="closebtn" onclick="toggleSidebar()">×</button>
        </div>
        <header class="header">
        <button class="openbtn" onclick="toggleSidebar()">☰</button>
            <h4>Versatto ERP</h4>
      
            <img 
                src="7124045_logout_icon.svg" 
                alt="Logout" 
                id="logout-icon" 
                onclick="window.location.href='login.html'" 
                style="cursor: pointer; width: 30px; height: 30px;">
        </header>

        <style>
            #logout-icon {
                filter: invert(100%); 
            }
        
            #logout-icon:hover {
                filter: invert(70%); 
            }
        </style>
        
<div class="content">
<form action="#">
<div class="input-group">
    <button type="button" class="add" onclick="window.location.href='CadastroProdutos.php'">Cadastrar Novo Produto</button>
    <button type="button" class="return" onclick="window.location.href='Home.html'">Retornar</button>
</div>


    <div>
        <table id="stock">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nome</th>
                    <th>Estoque Mínimo</th>
                    <th>Estoque Máximo</th>
                    <th>Estoque Disponível</th>
                    <th>Custo</th>
                    <th>Venda</th>
                    <th>Alteração</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Preenche os dados da tabela com os resultados da consulta
                while ($linha = ibase_fetch_assoc($resultado)) {
                    //var_dump($linha);
                    echo "<tr>";
                    echo "<td>" . $linha['ID_PRODUTO'] . "</td>";
                    echo "<td>" . $linha['NOME_PRODUTO'] . "</td>";
                    echo "<td>" . $linha['ESTOQUE_MINIMO'] . "</td>";
                    echo "<td>" . $linha['ESTOQUE_MAXIMO'] . "</td>";
                    echo "<td>" . $linha['QUANTIDADE_ESTOQUE'] . "</td>";
                    echo "<td>" . $linha['PRECO_CUSTO'] . "</td>";
                    echo "<td>" . $linha['PRECO_VENDA'] . "</td>";
                    echo "<td><a href='editarProduto.php?id=" . $linha['ID_PRODUTO'] . "'>Alterar Produto</a></td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</form>
</div>
</main>
<?php
// Fecha a conexão com o banco de dados
ibase_free_result($resultado);
ibase_close($conexao);
?>
<script src="scrip.js"></script>  
</body>
<div id="footer-container"></div>
</html>

