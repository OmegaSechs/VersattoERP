function loadSidebar() {
    fetch('sidebar.html')
       .then(response => response.text())
       .then(data => {
        document.getElementById('sidebar-container').innerHTML = data;
       });
}

function toggleSidebar() {
    var sidebar = document.getElementById("mySidebar");
    var main = document.getElementById("home");

    if (sidebar.style.width === "250px") {
        sidebar.style.width = "0";
        main.style.marginLeft = "0";
    } else {
        sidebar.style.width ="250px";
        main.style.marginLeft = "250px";
    }
}
   
function loadFooter() {
    fetch('footer.html')
       .then(response => response.text())
       .then(data => {
        document.getElementById('footer-container').innerHTML = data;
       });
}
   
  function addLoadEvent(func) { 
    var oldonload = window.onload; 
    if (typeof window.onload != 'function') { 
      window.onload = func; 
    } else { 
      window.onload = function() { 
        if (oldonload) { 
          oldonload(); 
        } 
        func(); 
      } 
    } 
  }
   
  addLoadEvent(loadSidebar); 
  addLoadEvent(loadFooter);